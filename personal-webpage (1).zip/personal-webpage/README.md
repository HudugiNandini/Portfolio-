# Personal Webpage

A Pen created on CodePen.

Original URL: [https://codepen.io/SquishyAndroid/pen/XjRPVV](https://codepen.io/SquishyAndroid/pen/XjRPVV).

A single page scrolling portfolio site I was working on using fullpage.js, wow.js and animate.css.